#!/bin/bash

host="89.208.17.53" password="Gooxu4ai" perl -Ilib  t/*
